# Lab 5 Tutorials

Introductory tutorials:

1. [Part 1](/tutorials/part1.md): Vue Setup
1. [Part 2](/tutorials/part2.md): Navigation
1. [Part 3](/tutorials/part3.md): Server Setup
1. [Part 4](/tutorials/part4.md): Authentication -- Back End
1. [Part 5](/tutorials/part5.md): Registration
1. [Part 6](/tutorials/part6.md): Login
1. [Part 7](/tutorials/part7.md): Uploading Photos
1. [Part 8](/tutorials/part8.md): Home Page

Additional functionality:

1. [Part 9](/tutorials/part9.md): Photo Page
1. [Part 10](/tutorials/part10.md): Comments

Running on Digital Ocean:

1. [Digital Ocean](/tutorials/digital-ocean.md)
